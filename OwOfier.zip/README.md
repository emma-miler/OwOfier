# OwOFier mod
OwOFier mod Titanfall 2 Northstar

# Compatibility
Compatible with Northstar v1.5.0
To use, make sure you add `-enablechathooks` to your launch arguments.

##UwU OwO UwU