# OwOFier mod
OwOFier mod Titanfall 2 Northstar

# READ!

Not yet compatible with mainline northstar! Use 1.5.0-rc1 with my commit on it